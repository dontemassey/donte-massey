DONTE DOMINIC MASSEY CAMPAIGN WEBSITE

Files:
- index.html — website content
- style.css — design and responsive layout
- script.js — mobile navigation

BEFORE PUBLISHING:
1. Replace campaign@example.com with the official campaign email.
2. Replace the donation button (#) with the official secure donation URL.
3. Confirm the exact ANC/SMD designation and update the title/header if desired.
4. Replace the campaign committee/disclaimer text with the exact legally required DC campaign disclosure.
5. Add Donte's approved campaign photo/logo if desired.

The site is a static website and can be uploaded to most web hosts.
